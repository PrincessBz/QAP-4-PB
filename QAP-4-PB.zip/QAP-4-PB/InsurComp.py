# Description: Program to enter and calculate new insurance policy for One Stop Company.
# Author: Princess Bazunu
# Dates: 2024-03-20

# Import libraries
import FormatValues as FV
import datetime
import sys
import time

# Define progarm constants.

# Open the default files.
f=open('Default.dat','r')
POLICY_NUM = int(f.readline())
BASIC_PREMIUM = float(f.readline())
DISCOUNT_EXTRA_CAR = float(f.readline())
EXTRA_LIAB_COV = float(f.readline())
GLASS_COV_COST = float(f.readline())
LOANER_CAR_COST = float(f.readline())
HST_RATE = float(f.readline())
MONTHLY_PROC_FEE = float(f.readline())
f.close()

CurDate = datetime.datetime.now()
Date = datetime.timedelta(days=6)

# Define program functions.

print()
# Main program.
while True:
    # Gather user input.
    Cust_First_Name = input("Enter Customer first name: ").title()
    Cust_Last_Name = input("Enter Customer last name: ").title()
    Cust_Address = input("Enter Address: ").title()
    City = input("Enter City: ").title()

    ProvLst = ["NL","NS","NB","PE","PQ","ON","MB","AB","BC","SK","NT","YT","NV"]
    while True:
        Prov = input("Enter the customer province (XX): ")
        if Prov == "":
            print("Error - cannot be blank.")
        elif len(Prov) != 2:
            print("Error - must be 2 characters only.")
        elif Prov not in ProvLst:
            print("Error - invalid province.")
        else:
            break
    print()

    Postal_Code = input ("Enter the postal code (XXX XXX): ")
    Phone_Num = input ("Enter the phone number(9999999999): ")
    Phone_Num = int(Phone_Num)
    Num_Cars_Insur = input("Enter the number of cars to be insured: ")
    Num_Cars_Insur = int(Num_Cars_Insur)

    print()

    # Optional Liabilities and coverages.
    while True:
        Extra_liability = input("Would you like to add an extra liability? (Y/N): ").upper()
        if Extra_liability == "N":
            ExtraLiabCost = 0
        else:
            # Extra_liability == "Y"
            # ExtraLiabCost = "Yes"
            break
        # elif Extra_liability == "N":
        #     Extra_liability_Display = "NO"
        # else:
            break

    while True:
        Glass_Coverage = input("Would you like to add Glass coverage? (Y/N): ").upper()
        if Glass_Coverage == "N":
            ExtraCostCov = 0
        else:
            # Glass_Coverage == "Y"
            # ExtraCostCov = "YES"
            break
        # elif Glass_Coverage == "N":
        #     Glass_Coverage_Display = "NO"
        # else:
        #     break 
    
    while True:
        Loan_Car = input("Would you like a loaner car? (Y/N): ").upper()
        if Loan_Car == "N":
            ExtraCostLoan = 0
        else:
            # Loan_Car == "Y"
            # ExtraCostLoan = "YES"
            break
        # elif Loan_Car == "N":
        #     Loan_Car_Display = "NO"
        # else:
        #     break

    
    print()
   

    # Perform calculations.
    
    Insur_Prem = BASIC_PREMIUM 

    if Insur_Prem >= 2:
        Insur_Prem_Add = (BASIC_PREMIUM * Num_Cars_Insur ) * DISCOUNT_EXTRA_CAR 
    else: 
        Insur_Prem = BASIC_PREMIUM

    if Extra_liability == "Y":
        ExtraLiabCost = Num_Cars_Insur * EXTRA_LIAB_COV 
    else: 
        ExtraLiabCost = 0
    
    if Glass_Coverage == "Y":
        ExtraCostCov = Num_Cars_Insur * GLASS_COV_COST
    else:
        ExtraCostCov = 0
   
    if Loan_Car == "Y" :
        ExtraCostLoan = Num_Cars_Insur * LOANER_CAR_COST
    else:
        ExtraCostLoan = 0
      
   

    TotalExtraCost = ExtraCostCov + ExtraCostLoan + ExtraLiabCost

    TotalInsurPre = Insur_Prem + TotalExtraCost

    HST = HST_RATE
    HST = TotalInsurPre * HST_RATE

    TotalCost = TotalInsurPre + HST
 
    PayMethLst = ["Full","Monthly","Down Pay"]
    while True:
        Down_Payment = 0
        Pay_Method = input("Enter Payment method (Full,Monthly,Down pay): ").title()
        if Pay_Method == "Full" :
            MonthlyPay = TotalCost + MONTHLY_PROC_FEE
            break

        elif  Pay_Method == "Monthly" :
            MonthlyPay = (TotalCost + MONTHLY_PROC_FEE) / 8
            break

        
        elif Pay_Method == "Down Pay":
            Down_Payment = input("Enter Amount of Down Payment: ")
            Down_Payment = float(Down_Payment)
            Pay_Method == "Down Pay"
            MonthlyPay = (TotalCost - Down_Payment + MONTHLY_PROC_FEE) / 8
            break
            
            
        elif Pay_Method == "":
            print("Error - Cannot be blank.")

        elif Pay_Method not in PayMethLst:
            print("Error - payment method must be entered as Full, Monthly or Down Pay.")

        else:
            break



    InvDate = CurDate
    FstPayDate = InvDate + Date
    



    # Display results

    print()
    print("===========================================")
    print("       ONE STOP INSURANCE RECEIPT        ")
    print("===========================================")
    print()
    print(f" POLICY N0: {POLICY_NUM:<4d}  INVOICE DATE: {FV.FDateM(InvDate):<10s} ")
    print("============================================")
    print()
    print(f" Insured: {Cust_First_Name:<10s}, {Cust_Last_Name:<10s}  ")
    print(f" Address: {Cust_Address:<18s}                       ")
    print(f" City,Prov: {City:<10s}, {Prov:<2s}              ")
    print(f" Postal Code: {Postal_Code:<7s}                   ")
    print(f" Phone: {Phone_Num:<10d}                         ")
    print()
    print("_______________________________________________")
    print()
    print(f" Number of Insured Cars: {Num_Cars_Insur:>20d}            ")
    print(f" Extra Liability Coverage: {Extra_liability:>19s}         ")
    print(f" Glass Coverage:  {Glass_Coverage:>28s}                   ")
    print(f" Loaner Car Coverage:  {Loan_Car:>23s}                    ")
    print()
    print(f" Payment Method: {Pay_Method:>30s}                        ")
    print(f" Down Payment:   {FV.FDollar2(Down_Payment):>30s}               ")
    print()
    print(f"_______________________________________________")
    print()
    print(f" Insurance Premium:  {FV.FDollar2(Insur_Prem):>25s}            ")
    print(f" Total Extra Cost:   {FV.FDollar2(TotalExtraCost):>25s}   ")
    print(f" Total Insurance Premium: {FV.FDollar2(TotalInsurPre):>20s} ")
    print(f" HST: {FV.FDollar2(HST):>40s}  ")
    print("                                    ----------")
    print(f" Total Cost: {FV.FDollar2(TotalCost):>33s}   ")
    print("                                    ----------")
    print("______________________________________________")
    print(f" Monthly Payment:  {FV.FDollar2(MonthlyPay):>27s}   ")
    print("                                    ----------")
    print(f" First Payment Date:  {FV.FDateS(FstPayDate)}    ")
    print()
    print("===============================================")


    POLICY_NUM += 1
    Claims = ["Claim_Num","Claim_Date","Claim_Amt"]
    while True:
        Claim_Num = input ("Enter claim number: ")
        Claim_Num = int(Claim_Num)
        Claim_Date = input ("Enter the claim date (YYYY-M-D): ")
        Claim_Date = datetime.datetime.strptime(Claim_Date, "%Y-%m-%d")
        Claim_Amt = input ("Enter the claim Amount: ")
        Claim_Amt = float(Claim_Amt)
       

        Claim_Num += 1

        program_continue = input ("Would you like to process another claim (Y/N): ").upper()
        if program_continue != "Y" and program_continue != "N":
            print("Data Entry Error - Must enter either Y or N, please try again.")
        else:
            break
        if program_continue == "N":
            break

       


    print()
    print("              Claims Details               ")
    print()
    print(f" Claim #         Claim Date        Amount")
    print(f"____________________________________________ ")
    print(f" {Claim_Num}      {Claim_Date}    {Claim_Amt}")
    print()
    print(f"_____________________________________________")
   
# Store the claim data into a file called Claims.lst
    for _ in range(5):  # Change to control no. of 'blinks'
        print('Saving claim data ...', end='\r')
        time.sleep(.3)  # To create the blinking effect
        sys.stdout.write('\033[2K\r')  # Clears the entire line and carriage returns
        time.sleep(.3)


    f = open("ClaimsLst.dat", "a")
    # All values written to file must be a string.  If you have a numeric
    # value, use the str() function to convert.
    f.write("{}, ".format(str(Claim_Num)))
    f.write("{}, ".format(str(Claim_Date)))
    f.write("{}\n ".format(str(Claim_Amt)))

    f.close()

 
    print()
    print("Claim data successfully saved ...", end='\r')
    time.sleep(1)  # To create the blinking effect
    sys.stdout.write('\033[2K\r')  # Clears the entire line and carriage returns
 


# Housekeeping.
    f = open("Default.dat","w")
   
    f.write("{}\n ".format(str(POLICY_NUM)))
    f.write("{}\n ".format(str(BASIC_PREMIUM)))
    f.write("{}\n ".format(str(DISCOUNT_EXTRA_CAR)))
    f.write("{}\n ".format(str(EXTRA_LIAB_COV)))
    f.write("{}\n ".format(str(GLASS_COV_COST)))
    f.write("{}\n ".format(str(LOANER_CAR_COST)))
    f.write("{}\n ".format(str(HST_RATE)))
    f.write("{}\n ".format(str(MONTHLY_PROC_FEE)))

    f.close()

    print(" Thank you for using One Stop Insurance Company!")